import os
from flask import Flask, jsonify

app = Flask(__name__)
#app.config['JSON_AS_ASCII'] = False

LOGIN_TITLE = os.getenv('LOGIN_TITLE', 'Вход по умолчанию')
WELCOME_MSG = os.getenv('WELCOME_MESSAGE', 'Добро пожаловать!')

@app.route('/')
def index():
    return jsonify({
        "service": "auth-service",
        "title": LOGIN_TITLE,
        "message": WELCOME_MSG
    })

@app.route('/health/live')
def liveness():
    return "OK", 200

@app.route('/health/ready')
def readiness():
    return "Ready", 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)