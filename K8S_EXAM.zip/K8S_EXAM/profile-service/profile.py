import os
from flask import Flask, jsonify
app = Flask(__name__)

@app.route('/')
def index():
    return jsonify({"service": "profile-service", "data": "User Profile Info"})

@app.route('/health/live')
def liveness(): return "OK", 200

@app.route('/health/ready')
def readiness(): return "Ready", 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)